import React from 'react'

export default function Projects(props) {
    // const propertiesElement=properties.map(property=>{
    //     let key=Math.random()*1000+""
    //     return(
    //         <PropertyItem {...property} key={key}/>
    //     )
    //})
    return (
        <div className='' style={{margin:'70px'}}>
            <h2>Projects</h2>
            <p>No projects</p>
        </div>
    )
}
